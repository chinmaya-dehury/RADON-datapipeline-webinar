import PIL
from PIL import Image, ImageOps, ImageDraw, ImageFont
from io import BytesIO
from os import path
import base64
import json
import random



def write_to_file(save_path, data):
  with open(save_path, "wb") as f:
    f.write(base64.b64decode(data))


def lambda_handler(event, context):
   
    # get the image from the "body" which is encoded in some format and is in the HTTP request itself.
    write_to_file("/tmp/photo.jpg", event["body"])

   
    print("Open the image from /tmp/ dir")
    img = Image.open('/tmp/photo.jpg')
    
    txt = Image.new('RGBA', img.size, (255,255,255,0))

    #Creating Text
    text = "RADON Data Pipeline Webinar"
    
    # font = ImageFont.truetype("arial.ttf", 82)

    #Creating Draw Object
    d = ImageDraw.Draw(txt)

    #Positioning Text
    width, height = img.size 
    # textwidth, textheight = d.textsize(text, font)
    textwidth, textheight = d.textsize(text)
    # x=width/2-textwidth/2
    # y=height-textheight-300

    #Applying Text
    # d.text((x,y), text, fill=(255,255,255, 125))
    # d.text((x,y), text, fill=(255,255,255, 125), font=font)

    y=200
    for i in range(7):
        x=random.randint(0, width-300)
        y+=random.randrange(0,int(height/8), 19)+random.randint(0,100)
        d.text((x,y), text, fill=(255,255,255, 75))

    #Combining Original Image with Text and Saving
    watermarked = Image.alpha_composite(img, txt)
    watermarked.save(r'/tmp/photo_watermarked.png')


    # print("# Convert grayscale image into utf-8 encoded base64")
    with open("/tmp/photo_watermarked.png", "rb") as imageFile:
      str = base64.b64encode(imageFile.read())
      encoded_img = str.decode("utf-8")

    print("Print the encoded image:")
    print(encoded_img)
    print("# Now return the encoded img.\n")

    return {
      "isBase64Encoded": True,
      "statusCode": 200,
      "headers": { "content-type": "image/jpeg"},
      "body": encoded_img
    }
