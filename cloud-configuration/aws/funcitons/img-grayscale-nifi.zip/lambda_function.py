import PIL
from PIL import Image, ImageOps
from io import BytesIO
from os import path
import base64
import json

origin_bucket = 'my-resizer'
destination_bucket = 'my-resized'
width_size = 200

def write_to_file(save_path, data):
  with open(save_path, "wb") as f:
    f.write(base64.b64decode(data))


def lambda_handler(event, context):
    print("Print the event object")
    print(event)
    # for key in event.get('Records'):
        # object_key = key['s3']['object']['key']
        # extension = path.splitext(object_key)[1].lower()

        # # Grabs the source file
        # obj = s3.Object(
        #     bucket_name=origin_bucket,
        #     key=object_key,
        # )
        # obj_body = obj.get()['Body'].read()
    
        # Checking the extension and
        # Defining the buffer format
    print("get the image from event[body]")
    print(event)
    # get the image from the "body" which is encoded in some format and is in the HTTP request itself.
    write_to_file("/tmp/photo.jpg", event["body"])

    # if extension in ['.jpeg', '.jpg']:
    #     format = 'JPEG'
    # if extension in ['.png']:
    #     format = 'PNG'

        # Resizing the image
    
    # img = Image.open(BytesIO(obj_body))
    # wpercent = (width_size / float(img.size[0]))
    # hsize = int((float(img.size[1]) * float(wpercent)))
    # img = img.resize((width_size, hsize), PIL.Image.ANTIALIAS)
    # buffer = BytesIO()
    # img.save(buffer, format)
    # buffer.seek(0)

    # file, ext = os.path.splitext('/tmp/photo.jpg')
    size = 64, 64
    print("Open the image from /tmp/ dir")
    img = Image.open('/tmp/photo.jpg')
    print("Grayscale the image.")
    gImg = ImageOps.grayscale(img)
    print("save the grayscale")
    gImg.save( "/tmp/photo_grayscale.jpg", "JPEG")


    # img1 = Image.open('/tmp/photo_thumbnail.jpg')
    # #rotate image
    # out = img1.rotate(45)
    # out.save('/tmp/rotate-thumb-img.jpg')
        # Uploading the image
        # obj = s3.Object(
        #     bucket_name=destination_bucket,
        #     key=object_key,
        # )
        # obj.put(Body=buffer)

        # Printing to CloudWatch
        # print('File saved at {}/{}'.format(
        #     destination_bucket,
        #     object_key,
        # ))
    # print("# Convert grayscale image into utf-8 encoded base64")
    with open("/tmp/photo_grayscale.jpg", "rb") as imageFile:
      str = base64.b64encode(imageFile.read())
      encoded_img = str.decode("utf-8")

    print("Print the encoded image:")
    print(encoded_img)
    print("# Now return the encoded img.\n")

    return {
      "isBase64Encoded": True,
      "statusCode": 200,
      "headers": { "content-type": "image/jpeg"},
      "body": encoded_img
    }
